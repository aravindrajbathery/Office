package com.project.weatherdetails.controller;

import com.project.weatherdetails.model.ResponseView;
import com.project.weatherdetails.service.WeatherService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class WeatherController {
    @Autowired
    WeatherService weatherService;
    
    Logger logger = LoggerFactory.getLogger(WeatherController.class);

    @GetMapping (path = {"get-weather-report/{city}"})
    public ResponseView getWeatherReport(@PathVariable("city") String city) {
    	long beginTime = System.currentTimeMillis();
        ResponseView res = weatherService.getWeatherReport(city,logger);
        long responseTime = System.currentTimeMillis() - beginTime;
        logger.trace("Response Time is:"+responseTime +" ms");
    	return res;
      }

    @GetMapping ("/get-ust-locations-weather-report")
    public List<ResponseView> getUstWeatherReports() {
    	List<ResponseView> ustWeatherReport = new ArrayList<ResponseView>();
    	long beginTime = System.currentTimeMillis();
    	ustWeatherReport = weatherService.getUstWeatherReports(logger);
    	long responseTime = System.currentTimeMillis() - beginTime;
    	logger.trace("Response Time is:"+responseTime +" ms");
        return ustWeatherReport;
    }
}
