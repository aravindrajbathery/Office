package com.project.weatherdetails;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeatherDetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
